<?php
// Base API URL configuration
define('BASE_API_URL', 'https://aniwatch-api-i02m.onrender.com');
?>
